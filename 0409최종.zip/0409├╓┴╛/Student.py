import numpy as np
import Subject
import System
import tkinter as tk
import time


class Student:

    def __init__(self, ID):
        self.ID = ID
        self.Mysubject = self.RecallSub(ID)     #ID.txt 파일에서 과목 가져오기, 없으면 생성
        self.Chonghakjum = self.Hakjumadder()   #self.Mysubject를 사용하여 총 학점 계산
        self.Junpilnum = self.Junpilchecker()   #self.Mysubject를 사용하여 본인이 수강한 전공필수 과목 수 계산
        self.Timeleft = 300
        
    def RecallSub(self, StudentName) :  #ID.txt 파일에서 과목 가져오기, 없으면 생성
        try  :
            f = open('Student_schedule/'+StudentName+'.txt', 'r')   #user의 ID.txt 가 있으면 열기
        except :
            f = open('Student_schedule/'+StudentName+'.txt', 'w+')   #없으면 해당 User의 아이디와 같은 이름의 txt파일 만든 후 0 반환
            f.close()
            return 0
        arr = []
        for line in f:                      #txt에 적혀있는 과목 줄만큼
            line = line.strip()             #줄의 양 끝 공백 제거 
            list= line.split('\t', 6)       #\t(탭)을 기준으로 나눈 후
            arr.extend([list])              #2차원 배열로 저장
            gwamok = np.array(arr)          #2차원 numpyarray로 형식을 바꾸어 저장
        f.close()
        return gwamok                   #numpyarray 반환

            

    def Hakjumadder(self):   #self.Mysubject를 사용하여 총 학점 계산
        temp = 0     #변수 저장용 str
        if isinstance(self.Mysubject, np.ndarray) is not True:  #self.Mysubject가 np.ndarray형식이 아닐때(과목이 아무것도 없을때)
            return 0                #0 반환
        hakjum = self.Mysubject [:,3]   # 학점이 있는 열 지정
        for i in range(len(hakjum)):      # 전부 더하기 
            temp = temp + int(hakjum[i])
        return temp         #더한 값 반환


    def Junpilchecker(self):    #self.Mysubject를 사용하여 본인이 수강한 전공필수 과목 수 계산
        if isinstance(self.Mysubject, np.ndarray) is not True:  #self.Mysubject가 np.ndarray형식이 아닐때(과목이 아무것도 없을때)
            return 0            #0 반환
        junpil = self.Mysubject [:,2]   #전공 필수 대한 열 지정
        countall = np.where(junpil == 'Required')   #'Required' 갯수 검색
        return int(len(countall[0]))        #갯수 반환


        #수강 신청 함수
    def Addclass(self, Classnum):       
        gumsek = Subject.Caller()[:,0]      #모든 과목 번호 가져오기
        time = Subject.Caller()[:,4]         #모든 과목 시간표 가져오기
        
        
        if Classnum in gumsek :     #받은 인자가 존재하는 과목 번호인지 검색, 존재할 시 진행
            datetonum = []          
            timetonum = []
            
            arr1 = []
            loca = np.where(gumsek == Classnum)     #받은 인자의 행렬 확인

            if self.Junpilnum < 4 and Subject.Caller()[int(loca[0][0])][2] != 'Required':   #전공 필수 과목을 먼저 4개 신청할수 있도록 제한
                print('You have to listen at least 4 mojor-required class first. You now have', self.Junpilnum ,'junpil class.')
                print('Please attend 4 or more mojor-required class first\n')
                return 1
            if self.Chonghakjum + int(Subject.Caller()[int(loca[0][0])][3]) > 17 :      #17학점이 넘지 않도록 제한
                print('Your max credit is 17. You now have', self.Chonghakjum,'.')
                print('Please try again\n')
                return 1
            arr2 = time[int(loca[0][0])].split('#')     #User가 수강한 과목에 대해 수업시간 저장
            date = arr2[::2]                #요일
            arr3 = arr2[1::2]               #시간과 수업 길이
            for i in range(len(arr3)):      #시간과 수업길이를 분리
                arr1.extend(list(arr3[i]))
            startingtime = arr1[::2]        #시간
            howlong = arr1[1::2]            #수업 길이
            for i in date:
                a = i.replace('Mon','1').replace('Tue','2').replace('Wed','3').replace('Thu','4').replace('Fri','5')    #요일을 숫자로 치환(이후 list에 대응하기 쉽게 )
                datetonum.append(a)
            for i in startingtime:
                a = i.replace('A','1').replace('B','2').replace('C','3').replace('D','4').replace('E','5').replace('F','6') #시간(영어)을 숫자로 치환
                timetonum.append(a)

            Myschedule = self.Makeschedule() # User 의 신청과목을 스케줄표로 바꿔줌

            for i in range(len(datetonum)) :        #날짜 수만큼 반복
                for j in range(int(howlong[i])) :   #수업 길이만큼 행 반복
                    if Myschedule[int(timetonum[i])+j-1][int(datetonum[i])-1] != 0 :  #User의 스케줄표와 신청한 과목의 시간이 겹치는지 확인 
                        print('Error! You have another class for the time of class you attending to.\n')    #겹칠시 반환
                        return 1

            f = open('Student_schedule/'+self.ID+'.txt','a')    #안겹치면 해당 User의 아이디와 같은 이름의 txt파일 열기
            for i in range(6) :
                adding = Subject.Caller()[(loca[0][0])][i]      #과목 추가
                f.write(adding)
                f.write('\t')

            f.write('\n')
            f.close()
            self.Mysubject = self.RecallSub(self.ID)    #각각의 함수로 self 변수 업데이트
            self.Junpilnum = self.Junpilchecker()
            self.Chonghakjum = self.Hakjumadder()
            print('Succesfully attended to class!\n')
                #add to mysubject
        else :
            print('There\'s no class that matches your request. Please try again.\n')   #수강신청 과목번호가 아닐 시 반환
            return 1    


        #수강 취소 함수
    def Deleteclass(self,Classnum): 
        if isinstance(self.Mysubject, np.ndarray) is not True:  #self.Mysubject가 np.ndarray형식이 아닐때(과목이 아무것도 없을때)
            print('Error! You don\'t have any class')           #reject
            return 1 
        gumsek = self.Mysubject[:,0]        #수강신청한 과목들의 과목번호 불러옴
        if Classnum in gumsek :             #받은 인자가 수강신청한 과목번호중 하나라면
            loca = np.where(gumsek == Classnum) #해당 과목의 행렬값 검색
            locainint=int(loca[0][0])       #튜플을 int 로 변환
            print('\nFound',Classnum,'!')
            print( 'Are you sure you want to drop out?\n')      #드랍할 것인지 재차 확인
            print( 'Type y for yes\n')
            TorF = input('')
            if TorF == 'y' :        # 확인 시
                slice1 = self.Mysubject[:locainint,:]   # 수강포기한 과목 위에 있는 과목만 list로 만듦
                slice2 = self.Mysubject[locainint+1:,:] # 수강포기한 과목 밑에 있는 과목만 list로 만듦
                deleted = np.concatenate([slice1,slice2])   #두 list를 병합(취소 과목만 없는채로 list 완성)
                f = open('Student_schedule/'+self.ID+'.txt', 'w') # 과목 저장 폴더에 덮어씌움
                for i in range(deleted.shape[0]):
                    for j in range(deleted.shape[1]):
                        f.write(deleted[i,j])
                        f.write('\t') 
                    f.write('\n')
                f.close()
                print('Succesfully deleted!')
                self.Mysubject = self.RecallSub(self.ID)        #self 변수 업데이트
                self.Chonghakjum = self.Hakjumadder()
                self.Junpilnum = self.Junpilchecker()  

        else :
            print('There\'s no class that matches your request. Please try again.')
            return 1 


    def Makeschedule(self):         #스케줄표로 변환해주는 함수
        if isinstance(self.Mysubject, np.ndarray) is not True:  #self.Mysubject가 np.ndarray형식이 아닐때(과목이 아무것도 없을때)
            return np.zeros([9,5])      #영행렬 반환
        Classnum = self.Mysubject[:,0]  #user가 신청한 과목의 수강번호
        Schedulelist = np.zeros([9,5])  #임시 영행렬
        time = self.Mysubject[:,4]      #user가 신청한 과목의 수업시간

        for subcount in range(len(Classnum)) :  #수강신청한 과목 수 만큼 반복
            datetonum = []
            timetonum = []
            arr1 = []

            arr2 = time[subcount].split('#')    #시간에서 #을 기준으로 행렬로 나눔
            date = arr2[::2]        #요일 정보 저장
            arr3 = arr2[1::2]       #시간정보
            for i in range(len(arr3)):  #수업 시간과 길이 정보를 분리
                arr1.extend(list(arr3[i]))
            startingtime = arr1[::2]    #수업시간
            howlong = arr1[1::2]        #수업 길이
            for i in date:      
                a = i.replace('Mon','1').replace('Tue','2').replace('Wed','3').replace('Thu','4').replace('Fri','5')   #요일을 숫자로 치환(이후 list에 대응하기 쉽도록 함)
                datetonum.append(a)
            for i in startingtime:
                a = i.replace('A','1').replace('B','2').replace('C','3').replace('D','4').replace('E','5').replace('F','6') #시간(영어)을 숫자로 치환
                timetonum.append(a)

            for i in range(len(datetonum)) :        #날짜 수만큼 반복
                for j in range(int(howlong[i])) :   #수업 길이만큼 행 반복
                    Schedulelist[int(timetonum[i])+j-1][int(datetonum[i])-1] = Classnum[subcount]    #행렬에 수업시간이 해당하는 위치에 과목 번호 입력
                    
        return np.array(Schedulelist)


    def Showschedule(self):             #스케줄 띄워줌 . ScheduleList
        print('   MON  TUE  WED  Thu  Fri ')
        print(self.Makeschedule())

    def Choice(self) : 
        while 1 : 
            Starttime = time.time()  #시작 시간
            if self.Timeleft < 0 :   #남은 시간이 없을 시
                print('Time out! please log in again.\n')
                break               #로그인 화면으로 돌아감
            print('\n\nYou are student class. Choose what action you will make')
            print('Type 1 to add class, type 2 to delete class, type 3 to see what class you\'ve added:') #student 수강신청 화면
            print('If you want to log out, type 4.')
            print('(Time left untill time out : ',round(self.Timeleft, 1),' sec)')
            action = input('')
            
            match action :              #input 확인
                case '1':               #수강신청 
                    print('\n\nClasses possible to attend : ') 
                    Subject.get()       #수강가능 과목 출력
                    print('What class are you adding?')
                    print('(Type a to abort)')

                    cl_num = input('')  #과목 번호 확인
                    if cl_num != 'a' :
                            self.Addclass(cl_num)          #수강신청 함수 호출
                    self.Timeleft = self.Timeleft + Starttime- time.time()        #걸린 시간 저장
                    
                case '2' :              #수강취소
                    print('What class are you deleting?')
                    print('(Type a to abort :)')
                    cl_num = input('')  #과목 번호 확인
                    if cl_num != 'a' :
                            self.Deleteclass(cl_num)  #수강정정 함수 호출
                    self.Timeleft = self.Timeleft + Starttime- time.time()        #걸린 시간 저장
                    
                case '3' :
                    schedule = self.Showschedule()  #스케줄표 열어주는 함수 호출
                    self.Timeleft = self.Timeleft + Starttime- time.time()        #스케줄표를 닫을 때까지 걸린 시간 저장
                    print('\n')
                case '4' :
                    return 0
                case _: 
                    print('Wrong input! please try again...\n')         #잘못된 입력시 에러
                    self.Timeleft = self.Timeleft + Starttime- time.time()
