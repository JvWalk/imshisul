import numpy as np
import Subject

def Check(CheckNum):      #매니져 화원가입시 매니저임을 확인할수 있는 인증코드를 저장
    managerCheckNum = '1234'
    if bool(CheckNum == managerCheckNum) : return CheckNum      #매니져 인증코드가 일치하면 통과
    else : return print("\nWrong Number.")          #일치하지 않으면 반환
    
class Manager :

        #수강신청 과목 추가 함수
    def AddSub(self):          
        Newsub = []
        Newsub.insert(0, self.classno())    # 과목 번호 추가
        Newsub.insert(1, self.name())    # 과목 이름 추가
        Newsub.insert(2, self.pilsu())    # 과목 전공필수 여부 추가
        Newsub.insert(3, self.hakjum())    # 과목 학점 추가
        Newsub.insert(4, self.time())    # 수업 시간 추가
        Newsub.insert(5, self.room())    # 수업 장소 추가
        self.add(Newsub)    #해당 정보를 basics.txt에 추가

    def classno(self):  #과목 번호 받는 함수
        while 1: 
            i = input("Enter class number : ")  #과목 번호 입력     
            if i in Subject.Caller()[:,0] :         #만약 수강과목 번호가 겹칠시 에러 반환
                print("Error! There is a subject that has the same subject number. Please try again")
            else :
                return i 

    def name(self):  #과목 이름 받는 함수
            i = input("Enter class name : ")
            return i

    def pilsu(self):   # 과목 전공필수 여부 받는 함수
            while 1 :
                    # i = input("Is it major pilsu? answer y for 'yes', n for 'no'")
                    i = input("\nChoose the class type\n1.Required\n2.Elective\nEnter the number : ") #사용자가 전공 필수 과목인지 선택
                    if i == '1' :
                            return ('Required')     #선택에 따른 값 반환
                            break
                    elif i == '2' :
                            return ('Elective')     #선택에 따른 값 반환
                            break
                    else : 
                            print('wrong input! try again')
                            continue

    def hakjum(self):     #과목 학점 입력
            i = input("Enter class credit:")
            return i

    def time(self):         #수업시간 입력
            d1 = input("\nChoose the day of the first class.\n1. Mon    2. Tue    3. Wed    4. Thu    5. Fri\nEnter the number : ")             #수업 요일, 시간 정함
            t1 = input("\nChoose the time of the class.\n1. A | 9:00\n2. B | 10:00\n3. C | 11:00\n4. D | 12:00\n5. E | 13:00\n6. F | 14:00\nEnter the number : ")
            day1, time1 = self.tradeTime(d1, t1)             #받은 인자에 대응하는 요일, 시간 반환
            hour1 = input("\nIs it experimental class? Type \'y\' for yes.\n Enter : ")  #일반과목 / 실험 과목 구분
            if hour1 == 'y' : # 1,2,아닐때 에러
                return (day1+'#'+time1+'4')               #실험과목일 시 바로 반환
            d2 = input("\nChoose the day of the second class.\n1. Mon    2. Tue    3. Wed    4. Thu    5. Fri\nEnter the number : ")        #실험과목이 아닐 시 두번째 요일, 시간 생성
            t2 = input("\nChoose the time of the class.\n1. A | 9:00\n2. B | 10:00\n3. C | 11:00\n4. D | 12:00\n5. E | 13:00\n6. F | 14:00\nEnter the number : ")
            day2, time2 = self.tradeTime(d2, t2)             #받은 인자에 대응하는 요일, 시간 반환
            return (day1+'#'+time1+'1'+'#'+day2+'#'+time2+'1')          #해당 값 반환

    def room(self):
        while 1:    
            gwan = input("\nChoose the hall\n1. Woncheon   2. Seongho   3. Hyegang\n")
            if gwan == 1 or 2 or 3 :
                 gwan = gwan.replace('1', 'Woncheon').replace('2','Seongho').replace('3','Hyegang')
                 break
            else :
                 print("2-This option is not available. Please enter the available number.\n")
                 continue
        roomnum = input("Enter room number : ")
        return (gwan+'#'+roomnum)
            
    def add(self, Newsub):      #받은 리스트를 basics.txt 에 저장해주는 함수
            f = open("basics.txt",'a')
            for i in range(len(Newsub)) :     #받은 list의 길이만큼
                    temp = Newsub[i]           #list를 str 로 변환
                    f.write(temp)               #txt파일에 입력
                    f.write('\t')
            f.write('\n')
            f.close()

    def tradeTime(self,day, time):         #요일과 시간을 숫자에서 단어로 치환해주는 함수
            day = day.replace('1','Mon').replace('2','Tue').replace('3','Wed').replace('4','Thu').replace('5','Fri')
            time = time.replace('1','A').replace('2','B').replace('3','C').replace('4','D').replace('5','E').replace('6','F')
            return day, time



        #수강신청 과목 삭제 함수
    def DeleteSub(self):
        print('\nWhat class do you want to delete?')
        print('(You can abort by typing \'k\')')
        keyword = input('search by class number : ') #삭제를 원하는 과목번호 입력
        gumsek = np.array(Subject.Caller())     #수강신청 과목 불러오기
        index = gumsek[:,:1]        #과목 번호만 따로 추출
        if keyword in index :      #만약 입력값이 존재하는 과목 번호 중 하나라면
            loca = np.where(gumsek == keyword)      #해당 과목의 행렬 검색
            locainint=int(loca[0])              #과목의 행을 튜플에서 int로 변환
            print('\nfound',keyword,'!')
            print( 'is', gumsek[locainint,:],'the right class?\n')  #해당 과목 정보를 출력해주며, 정말로 지울 것인지 재차 확인 
            isitright=input('type y for\'yes\'\n')
            if isitright == 'y':                        #확인 받을 시
                slice1 = gumsek[:locainint,:]           #삭제할 과목의 위에 과목들을 따로 list로 저장
                slice2 = gumsek[locainint+1:,:]           #삭제할 과목의 밑에 과목들을 따로 list로 저장
                deleted = np.concatenate([slice1,slice2])   #위 두 list를 병합 (삭제 과목만 없는채로 list 완성)
                Subject.Changer(deleted)            #overwrite 해주는 함수 실행
                print('succesfully deleted!')
                Subject.get()
                a = input('if you want to delete more, type y\n')
                if a == 'y' :
                    return 1            #추가적으로 삭제 작업 시 반복
                else :
                    return 0            #아닐 시 탈출
            else :
                print('wrong input! try again') 
                return 1
        elif keyword == 'k' :       #지우기 탭에서 나가고 싶을 때 탈출
            return 0
        else : 
            print('\nCouldn\'t locate class... please try again\n' ) 
            return 1



        #수강신청 과목 수정 함수
    def ModSub(self):
        print('What class do you want to modify?')
        print('(You can abort by typing \'k\')')
        keyword = input('Search by class number : ')        #과목 번호로 입력
        gumsek = np.array(Subject.Caller())     #수강신청 과목 불러오기             
        index = gumsek[:,:1]         #과목 번호만 따로 추출
        if keyword in index :       #만약 입력값이 존재하는 과목 번호 중 하나라면
            loca = np.where(index == keyword)     #해당 과목의 행렬 검색
            locainint=int(loca[0])              #과목의 행을 튜플에서 int로 변환
            print('\nFound',keyword,'!')
            print( 'Is', gumsek[locainint,:],'the right class?\n') #해당 과목 정보를 출력해주며, 정말로 맞는지 재차 확인 
            isitright=input('Type y for\'yes\'\n')      #확인 받을 시
            if isitright == 'y':
                        print('What do you want to change?')    #바꿀 내용 선택
                        what = input('Number : 1, Name : 2, Elective/Required : 3, Credit : 4, Time : 5, Place : 6\n')
                        match what:
                            case '1':           #입력받은 값에 맞는 열을 할당하여 바꾸게 해줌
                                how = input('how do you want to change?\n')
                                gumsek[locainint,0] = how
                                Subject.Changer(gumsek)     #overwrite 해주는 함수 실행
                            case '2':
                                how = input('how do you want to change?')
                                gumsek[locainint,1] = how
                                Subject.Changer(gumsek)
                            case '3':
                                how = input('how do you want to change?')
                                gumsek[locainint,2] = how
                                Subject.Changer(gumsek)
                            case '4':
                                how = input('how do you want to change?')
                                gumsek[locainint,3] = how
                                Subject.Changer(gumsek)
                            case '5':
                                how = input('how do you want to change?')
                                gumsek[locainint,4] = how
                                Subject.Changer(gumsek)
                            case '6':
                                how = input('how do you want to change?')
                                gumsek[locainint,5] = how
                                Subject.Changer(gumsek)
                            case _:
                                    
                                print("\nThis option is not available. Please enter the available number.")

                        print('succesfully changed!')
                        a = input('if you want to delete more, type y\n')
                        if a == 'y' :
                            return 1            #추가적으로 삭제 작업 시 반복
                        else :
                            return 0            #아닐 시 탈출
        elif keyword == 'k' :       #바꾸기 탭에서 나가고 싶을 때 탈출
            return 0
        else : 
            print('\ncouldn\'t locate class... please try again\n' ) 
            return 1

         #매니져 수강신청 프로그램
    def Choice(self):  
        while 1: 
            Subject.get()       #수강신청 가능한 과목 출력
            print("\nChoose the Option.") 
            print("1. Add subject")
            print("2. Delete subject")
            print("3. Modify subject")
            print("4. Logout")
            managerOption = input("Enter the number : ")    #사용자가 작업할 내용 선택
            match managerOption :
                case '1':           #과목 추가
                    while (1) :
                        self.AddSub()
                        more = input('Complete! For adding more subject, Enter \'m\'\n') 
                        if more != 'm': break
                case '2':           #과목 제거
                    while (1) :
                        a = self.DeleteSub()
                        if a != 1: break
                case '3':          #과목 내용 정정
                    while (1) :
                        a = self.ModSub()
                        if a != 1: break
                case '4':          #로그 아웃
                    return 0
                case _:
                    print("\nThis option is not available. Please enter the available number.")