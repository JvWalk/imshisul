import tkinter as tk
import numpy as np

def get():
    subjectFile = open("basics.txt", 'r')
    subject = subjectFile.readlines()
    subjectList = [x.split() for x in subject]
    subjectInfo = {}
    for i in subjectList: print(*i)

def Caller():
    f = open("basics.txt", 'r')
    arr = []
    for line in f:
        line = line.strip()
        list= line.split('	', 6)
        arr.extend([list])
        gwamok = np.array(arr)
    f.close()
    return gwamok

def Changer(Gwamok):
    f = open("basics.txt", 'w')
    for i in range(Gwamok.shape[0]):
        for j in range(Gwamok.shape[1]):
            f.write(Gwamok[i,j])
            f.write('\t') 
        f.write('\n')
    f.close()