import numpy as np
import tkinter as tk
import Manager
##from tkinter.tix import *

def GwamokCaller():
    f = open("basics.txt", 'r')
    arr = []
    for line in f:
        line = line.strip()
        list= line.split('	', 6)
        arr.extend([list])
        gwamok = np.array(arr)
    f.close()

def GwamokChanger(Gwamok):
    f = open("basics.txt", 'w')
    for i in range(Gwamok.shape[0]):
        for j in range(Gwamok.shape[1]):
            f.write(Gwamok[i,j])
            f.write('\t') 
        f.write('\n')
    f.close()

def GwamokShower():
    popup=tk.Tk()
    popup.title("YUN DAE HEE")
    popup.geometry("900x1000+100+1")
    popup.resizable(False, False)

    label = tk.Label(popup, height=1)
    show = tk.Label(text="class number", width=20, height=2)
    show.grid(row=0, column=0)
    show = tk.Label(text="class name", width=20, height=2)
    show.grid(row=0, column=1)
    show = tk.Label(text="class pilsu", width=20, height=2)
    show.grid(row=0, column=2)
    show = tk.Label(text="class credit", width=20, height=2)
    show.grid(row=0, column=3)
    show = tk.Label(text="class time", width=20, height=2)
    show.grid(row=0, column=4)
    show = tk.Label(text="class room", width=20, height=2)
    show.grid(row=0, column=5)
    for i in range(GwamokCaller.gwamok.shape[0]):
        for j in range(GwamokCaller.gwamok.shape[1]):
            show  = tk.Label(text=GwamokCaller.gwamok[i][j], width=20, height=2)
            show.grid(row=i+1, column=j)
        
    # popup.mainloop()


def membership(UserList):
    while 1:
        print("\nChoose your User Type. ")
        print("1. Manager")
        print("2. Student")
        print("3. Go back")
        Type = input("Enter the number : ")
        match Type: #Manager로 회원가입
            case '1':
                Type = "Manager"
                CheckNum = input("Enter the Manager check number : ")
                if Manager.Check(CheckNum) == CheckNum : break # 맞으면 Manager로 설정
                else : continue     #틀리면 다시 반복문
            case '2' :    # Student로 회원가입
                Type = "Student"
                break
            case '3' : return # 첫페이지로 이동
            case _: # Option에 없는 수 입력 : Error 
                print("2-This option is not available. Please enter the available number.\n")
                continue
    while 1 : # 아이디 설정
            ID = input("Enter your new ID : ")
            if ID in UserList : #입력받은 ID가 UserList의 key(=ID)에 존재하는 경우
                print("This Identifier is exist. Please create another ID.\n")
                continue # 다시 아이디 설정
            else : break 
    Password = input("Enter your new Password : ")
    UserList[ID] = {Password : Type}
    #### + def(Type구분) : Type구분해서 사용자 structure 생성해주는 함수
    print("\n*** Welcome to Ajou University! ****\n*** We return to the first Page. ***\n")

def login(UserList):
    while 1 : 
        GobackCheck = 0
        ID = input("Enter your ID : ")        
        if(ID in UserList): break
        else : 
            print("\nThere is no User with this ID.\n")
            GobackCheck = input("1. Retry\n2. Go back\nEnter : ")
            if GobackCheck == '1' : continue
            else : break
    if GobackCheck == '2' : return ID == '', Password == ''
    else : pass
    while 1 : 
        Password = input("Enter your Password : ")
        if(Password in UserList[ID].keys()): break
        else :
            print("Wrong password.\n")
            GobackCheck = input("1. Retry\n2. Go back\nEnter : ")
            if GobackCheck == '1' : continue
            else : break
    if GobackCheck == '2' : return
    else : pass
    print("Login success.\n")
    return ID, Password