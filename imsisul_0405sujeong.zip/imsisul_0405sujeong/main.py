# import Manager
# import Student 
import numpy as np
# import managerCheck
import Manager
import System

UserList = {} # 이중 dictionary형태 UserList = { ID : { Type : PW } }

# def getSubject():
#     subjectFile = open("basics.txt", 'r')
#     subject = subjectFile.readlines()
#     subjectList = [x.split() for x in subject]
#     subjectInfo = {}
#     for i in subjectList: print(*i)


print("\n-------------------------\n     Ajou University     \n-------------------------") 

while(1): 
    print("\nChoose the option you want.")
    print("1. Join membership")
    print("2. Login")
    print("3. Exit")
    choice = input("Enter the number : ")
    match choice: # 회원가입 반복문
        case '1':
            System.membership(UserList)
        case '2': #Login 아이디중복X
            ID, Password = System.login(UserList)
            if ID == '': continue # 사용자가 
            System.GwamokShower()
            if UserList[ID][Password] == "Manager" :
                while 1:
                    if Manager.Choice() == 4 : break
                    else : continue  
            else : # UserList[ID][Password] == "Student" 
                System.GwamokCaller()
        case '3': #Exit
             exit()
        case _: #Wrong Choice
             print("\n1-This option is not available. Please enter the available number.")
             continue
