import tkinter as tk
import numpy as np

def get():
    try :
        with open("basics.txt", 'r') as f:
            subject = f.readlines()
            subjectList = [x.split() for x in subject]
            for i in subjectList: print(*i)
    except: 
        print("FileNotFoundError! The program will exit.")
        exit(0)
    return subjectList


def Changer(Gwamok):
    try:
        with open("basics.txt", 'w') as f:
            for i in range(Gwamok.shape[0]):
                for j in range(Gwamok.shape[1]):
                    f.write(Gwamok[i,j])
                    f.write('\t') 
                f.write('\n')
    except: 
        print("FileNotFoundError! The program will exit.")
        exit(0)
        
def Caller():
    f = open("basics.txt", 'r')
    arr = []
    for line in f:
        line = line.strip()
        list= line.split('	', 6)
        arr.extend([list])
        gwamok = np.array(arr)
    f.close()
    return gwamok


