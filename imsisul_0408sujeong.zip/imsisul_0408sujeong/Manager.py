import numpy as np
import Subject

def Check(CheckNum):
    managerCheckNum = '1234'
    if bool(CheckNum == managerCheckNum) : return CheckNum
    else : return print("\nWrong Number.")

def AddSub():
    Newsub = []
    day1=int
    day2=int
    time1=int
    time2=int
    grade=int
    roomnum=int

    def classno():
        i = input("Enter class number : ")
        Newsub.insert(0, i)
    def name():
            i = input("Enter class name : ")
            Newsub.insert(1, i)
    def pilsu():
            while 1 :
                    # i = input("Is it major pilsu? answer y for 'yes', n for 'no'")
                    i = input("\nChoose the class type\n1.Required\n2.Elective\nEnter the number : ")
                    if i == '1' :
                            Newsub.insert(2, 'Required')
                            break
                    elif i == '2' :
                            Newsub.insert(2, 'Elective')
                            break
                    else : 
                            print('wrong input! try again')
                            continue

    def hakjum():
            i = input("Enter class credit:")
            Newsub.insert(3, i)

    def time():
            d1 = input("\nChoose the day of the first class.\n1. Mon    2. Tue    3. Wed    4. Thu    5. Fri\nEnter the number : ")
            t1 = input("\nChoose the time of the class.\n1. A | 9:00\n2. B | 10:00\n3. C | 11:00\n4. D | 12:00\n5. E | 13:00\n6. F | 14:00\nEnter the number : ")
            day1, time1 = tradeTime(d1, t1)
            hour1 = input("\nChoose the hour class will take place.\n1. Theory class : 1 hour \n2. Experimental class : 4 hour \nEnter the number : ")
            d2 = input("\nChoose the day of the second class.\n1. Mon    2. Tue    3. Wed    4. Thu    5. Fri\nEnter the number : ")
            t2 = input("\nChoose the time of the class.\n1. A | 9:00\n2. B | 10:00\n3. C | 11:00\n4. D | 12:00\n5. E | 13:00\n6. F | 14:00\nEnter the number : ")
            day2, time2 = tradeTime(d2, t2)
            hour2 = input("\nChoose the hour class will take place.\n1. Theory class : 1 hour \n2. Experimental class : 4 hour \nEnter the number : ")
            Newsub.insert(4, day1+'#'+time1+hour1+'#'+day2+'#'+time2+hour2)

    def room():
            gwan = input("Enter hall : ")
            roomnum = input("Enter room number : ")
            #if 시간과 강의실 중복검사
            Newsub.insert(5, gwan+'#'+roomnum)
            
    def add():
            f = open("basics.txt",'a')
            f.write('\n')
            for i in range(6) :
                    idk = Newsub[i]
                    f.write(idk)
                    f.write('\t')
            f.close()

    def tradeTime(self, day, time):
            match day:
                    case '1': day = 'Mon'
                    case '2': day = 'Tue'
                    case '3': day = 'Wed'
                    case '4': day = 'Thu'
                    case '5': day = 'Fri'
            self.time = chr(ord(time) + 16)
            return day, time


def DeleteSub():
    print('what class do you want to delete?')
    print('(you can abort by typing \'k\')')
    keyword = input('search by class number : ')
    gumsek = Subject.Caller.gwamok[:,:1]
    if keyword in gumsek :
        loca = np.where(gumsek == keyword)
        locainint=int(loca[0])
        print(locainint)
        print('\nfound',keyword,'!')
        print( 'is', Subject.Caller.gwamok[locainint,:],'the right class?\n')
        isitright=input('type y for\'yes\'\n')
        if isitright == 'y':
            slice1 = Subject.Caller.gwamok[:locainint,:]
            slice2 = Subject.Caller.gwamok[locainint+1:,:]
            deleted = np.concatenate([slice1,slice2])
            Subject.Changer.all(deleted)
            print('succesfully deleted!')
            a = input('if you want to delete more, type y\n')
            if a == 'y' :
                return 1
            else :
                return 0
        else :
            print('wrong input! try again') 
            return 1
    elif keyword == 'k' :
        return 0
    else : 
        print('\nCouldn\'t locate class... please try again\n' ) 
        return 1
    # def gumsekjung():
    # 	if 


def ModSub():
    print('What class do you want to modify?')
    print('(You can abort by typing \'k\')')
    keyword = input('search by class number : ')
    gumsek = Subject.Caller.gwamok[:,:1]
    if keyword in gumsek :
        loca = np.where(gumsek == keyword)
        locainint=int(loca[0])
        print(locainint)
        print('\nfound',keyword,'!')
        print( 'is', Subject.Caller.gwamok[locainint,:],'the right class?\n')
        isitright=input('type y for\'yes\'\n')
        if isitright == 'y':
                    print('what do you want to change?')
                    what = input('number: 1, name : 2, credit:3, junpil: 4,  time: 5, place : 6\n')
                    changing = Subject.Caller.gwamok
                    match what:
                        case '1':
                            how = input('how do you want to change?\n')
                            changing[locainint,0] = how
                            Subject.Changer.all(changing)
                            
                        case '2':
                            how = input('how do you want to change?')
                            changing[locainint,1] = how
                            Subject.Changer.all(changing)
                        case '3':
                            how = input('how do you want to change?')
                            changing[locainint,2] = how
                            Subject.Changer.all(changing)
                        case '4':
                            how = input('how do you want to change?')
                            changing[locainint,3] = how
                            Subject.Changer.all(changing)
                        case '5':
                            how = input('how do you want to change?')
                            changing[locainint,4] = how
                            Subject.Changer.all(changing)
                        case '6':
                            how = input('how do you want to change?')
                            changing[locainint,5] = how
                            Subject.Changer.all(changing)
                        case _:
                                
                            print("\nThis option is not available. Please enter the available number.")

                    print('succesfully changed!')
                    a = input('if you want to delete more, type y\n')
                    if a == 'y' :
                        return 1
                    else :
                        return 0
    elif keyword == 'k' :
        return 0
    else : 
        print('\ncouldn\'t locate class... please try again\n' ) 
        return 1
    


def Choice():
    print("\nChoose the Option.")
    print("1. Add subject")
    print("2. Delete subject")
    print("3. Modify subject")
    print("4. Logout")
    managerOption = input("Enter the number : ")
    match managerOption :
        case '1':
            while (1) :
                AddSub.classno()
                AddSub.name()
                AddSub.pilsu()
                AddSub.hakjum()
                AddSub.time()
                AddSub.room()
                AddSub.add()
                more = input('Complete! For adding more subject, Enter \'m\'\n')
                if more == 'm':
                    continue
                else :
                    break
        case '2':
            while (1) :
                a = DeleteSub.ask()
                if a != 1: break
        case '3':
            while (1) :
                a = ModSub.ask()
                if a != 1: break
        case '4':
            return 4
        case _:
            print("\nThis option is not available. Please enter the available number.")